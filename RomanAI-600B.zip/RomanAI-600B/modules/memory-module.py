#!/usr/bin/env python3
"""
Memory Module for 4DLLM-RomanAI (FAST EDITION)
Copyright Daniel Harding - RomanAILabs

High-performance persistent memory system.
Append-only, cached, lazy-loaded, zero redundant scans.
"""

from __future__ import annotations

import os
import json
import time
import re
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any


# ==============================================================================
# CONFIG
# ==============================================================================
MAX_MEMORY_SECONDS = 7 * 24 * 60 * 60   # 1 week
FLUSH_INTERVAL = 5.0                  # seconds
MAX_CONTEXT_MESSAGES = 2000


# ==============================================================================
# MEMORY MODULE (FAST)
# ==============================================================================
class MemoryModule:
    def __init__(self, memory_file: Optional[str] = None, script_dir: Optional[str] = None):
        self.script_dir = script_dir or os.getcwd()

        # Core paths
        base_dir = script_dir or os.path.expanduser("~/.4dllm_romanai")
        os.makedirs(base_dir, exist_ok=True)

        self.memory_file = memory_file or os.path.join(base_dir, "memory.jsonl")
        self.tags_file = os.path.join(base_dir, "memory_tags.json")
        self.relationship_file = os.path.join(base_dir, "relationships.json")
        self.mood_file = os.path.join(base_dir, "mood.json")

        # Runtime state
        self.memories: List[Dict[str, Any]] = []
        self.tags_index: Dict[str, Any] = {}
        self.relationship_state: Dict[str, Any] = {}
        self.mood_state: Dict[str, Any] = {}

        self._last_flush = 0.0
        self._dirty = False

        self._load_all()


    # ==========================================================================
    # LOADERS
    # ==========================================================================
    def _load_all(self) -> None:
        self._load_memory()
        self._load_aux(self.tags_file, {"tags": {}, "updated": ""}, "tags_index")
        self._load_aux(self.relationship_file, {"people": {}, "anchors": []}, "relationship_state")
        self._load_aux(self.mood_file, {"mood": "neutral", "energy": 0.5, "notes": ""}, "mood_state")

    def _load_aux(self, path: str, default: Any, attr: str) -> None:
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    setattr(self, attr, json.load(f))
            else:
                setattr(self, attr, default)
        except Exception:
            setattr(self, attr, default)

    def _load_memory(self) -> None:
        if not os.path.exists(self.memory_file):
            return
        try:
            with open(self.memory_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        self.memories.append(json.loads(line))
                    except Exception:
                        continue
        except Exception:
            self.memories = []


    # ==========================================================================
    # CORE MEMORY OPS
    # ==========================================================================
    def add_memory(self, role: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        now = time.time()
        entry = {
            "timestamp": now,
            "datetime": datetime.now(timezone.utc).isoformat(),
            "role": role,
            "content": content,
            "metadata": metadata or {}
        }

        self.memories.append(entry)
        self._dirty = True

        # Fast prune (no sort)
        cutoff = now - MAX_MEMORY_SECONDS
        if len(self.memories) > MAX_CONTEXT_MESSAGES:
            self.memories = [m for m in self.memories if m["timestamp"] > cutoff]

        # Update indexes cheaply
        self._update_tags(entry)
        if role == "user":
            self._update_relationship(entry)
        else:
            self._update_mood(entry)

        self._maybe_flush()


    # ==========================================================================
    # FAST PERSISTENCE
    # ==========================================================================
    def _maybe_flush(self) -> None:
        now = time.time()
        if not self._dirty or now - self._last_flush < FLUSH_INTERVAL:
            return

        try:
            with open(self.memory_file, "a", encoding="utf-8") as f:
                for m in self.memories:
                    if not m.get("_saved"):
                        f.write(json.dumps(m, ensure_ascii=False) + "\n")
                        m["_saved"] = True

            self._save_aux(self.tags_file, self.tags_index)
            self._save_aux(self.relationship_file, self.relationship_state)
            self._save_aux(self.mood_file, self.mood_state)

            self._last_flush = now
            self._dirty = False
        except Exception:
            pass

    def _save_aux(self, path: str, data: Any) -> None:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception:
            pass


    # ==========================================================================
    # CONTEXT / QUERIES
    # ==========================================================================
    def get_recent_memories(self, max_count: int = 20) -> List[Dict[str, Any]]:
        return self.memories[-max_count:]

    def get_memory_summary(self, max_count: int = 20) -> str:
        out = []
        for m in self.memories[-max_count:]:
            prefix = "You> " if m["role"] == "user" else "AI> "
            out.append(prefix + m["content"].strip())
        return "\n".join(out)

    def find_memories_by_tag(self, tag: str, max_count: int = 10) -> List[Dict[str, Any]]:
        tag = tag.lower()
        return [m for m in reversed(self.memories) if tag in m["content"].lower()][:max_count]


    # ==========================================================================
    # INDEX UPDATES (FAST)
    # ==========================================================================
    TAG_RE = re.compile(r"[a-z0-9][a-z0-9_\-]{2,}")

    def _update_tags(self, entry: Dict[str, Any]) -> None:
        text = entry["content"].lower()
        tags = self.TAG_RE.findall(text)
        tag_map = self.tags_index.setdefault("tags", {})

        for t in tags[:8]:
            info = tag_map.setdefault(t, {"count": 0})
            info["count"] += 1

        self.tags_index["updated"] = datetime.now(timezone.utc).isoformat()

    def _update_relationship(self, entry: Dict[str, Any]) -> None:
        if "daniel" not in entry["content"].lower():
            return
        people = self.relationship_state.setdefault("people", {})
        daniel = people.setdefault("Daniel", {"notes": [], "last_seen": ""})
        daniel["last_seen"] = datetime.now(timezone.utc).isoformat()
        if "Primary user" not in daniel["notes"]:
            daniel["notes"].append("Primary user")

    def _update_mood(self, entry: Dict[str, Any]) -> None:
        text = entry["content"].lower()
        mood = self.mood_state.get("mood", "neutral")
        energy = float(self.mood_state.get("energy", 0.5))

        if any(w in text for w in ("happy", "excited", "thanks")):
            mood = "positive"
            energy = min(1.0, energy + 0.05)
        elif any(w in text for w in ("tired", "sad", "anxious")):
            mood = "reflective"
            energy = max(0.0, energy - 0.05)

        self.mood_state.update({
            "mood": mood,
            "energy": round(energy, 3),
            "updated": datetime.now(timezone.utc).isoformat()
        })


    # ==========================================================================
    # COMPAT WRAPPERS
    # ==========================================================================
    def observe_user(self, text: str, meta: Optional[Dict[str, Any]] = None) -> None:
        self.add_memory("user", text, meta)

    def observe_assistant(self, text: str, meta: Optional[Dict[str, Any]] = None) -> None:
        self.add_memory("assistant", text, meta)

